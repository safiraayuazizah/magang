<?php

namespace App\Http\Controllers;

use App\Models\penilaian_dantim;
use Illuminate\Http\Request;

class PenilaianDantimController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\penilaian_dantim  $penilaian_dantim
     * @return \Illuminate\Http\Response
     */
    public function show(penilaian_dantim $penilaian_dantim)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\penilaian_dantim  $penilaian_dantim
     * @return \Illuminate\Http\Response
     */
    public function edit(penilaian_dantim $penilaian_dantim)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\penilaian_dantim  $penilaian_dantim
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, penilaian_dantim $penilaian_dantim)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\penilaian_dantim  $penilaian_dantim
     * @return \Illuminate\Http\Response
     */
    public function destroy(penilaian_dantim $penilaian_dantim)
    {
        //
    }
}
